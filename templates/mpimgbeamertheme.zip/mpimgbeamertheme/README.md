HSRM Beamer Theme
=================

Die [Beamer Klassen](http://www.tex.ac.uk/CTAN/macros/latex/contrib/beamer/doc/beameruserguide.pdf) für LaTeX dienen zur Erstellung von Präsentationen, welche mit einem Projektor vorgeführt werden sollen. Das Textsatzsystem erzeugt dazu PDF Dateien, die von einer großen Anzahl an Programmen gezeigt werden können.
	
Das MPIMG Theme ebenso steht unter der [GNU Public License](http://www.gnu.org/licenses/gpl-3.0.en.html). Es darf also weitergegeben und modifiziert werden, sofern die Lizenzart beibehalten wird.

Das MPIMG Theme basiert auf dem MSRM Theme von Benjamin Weiss. https://github.com/benjamin-weiss/hsrmbeamertheme
